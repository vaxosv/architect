import * as $ from 'jquery';
const css = require('./main.scss');


class site {
    constructor(){}
}

new site();


if()
